// app/screens/testpage1.tsx
import { Text, View } from "react-native";

export default function TestPage1() {
  return (
    <View>
      <Text>이곳은 TestPage1 입니다!</Text>
    </View>
  );
}
