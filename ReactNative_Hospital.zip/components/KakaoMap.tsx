import React, { forwardRef } from "react";
import { StyleSheet, View } from "react-native";
import { WebView } from "react-native-webview";

type KakaoMapProps = {
  latitude?: number; // 도착지 위도
  longitude?: number; // 도착지 경도
};

const KakaoMap = forwardRef<WebView, KakaoMapProps>(({ latitude, longitude }, ref) => {
  const KAKAO_MAP_JS_KEY = `150e98e3bd883753e02d811c6dfa864c`;
  const KAKAO_MOBILITY_KEY = `59498ffaa12716e02333174a9e4bac54`;

  const htmlContent = `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8" />
      <script src="https://dapi.kakao.com/v2/maps/sdk.js?appkey=${KAKAO_MAP_JS_KEY}&libraries=services"></script>
      <style>html, body, #map { height: 100%; margin: 0; padding: 0; }</style>
    </head>
    <body>
      <div id="map"></div>
      <script>
        let map;
        const endLat = ${latitude};
        const endLng = ${longitude};
        const endPosition = new kakao.maps.LatLng(endLat, endLng);

        window.onload = () => {
          map = new kakao.maps.Map(document.getElementById('map'), {
            center: endPosition,
            level: 3
          });

          new kakao.maps.Marker({ position: endPosition, map: map });
          new kakao.maps.CustomOverlay({
            position: endPosition,
            content: '<div style="padding:5px; background:white; border:1px solid black; border-radius:3px;">도착</div>',
            yAnchor: 0
          }).setMap(map);
        };

        // React Native에서 위치 데이터 전달받기
        document.addEventListener("message", function(event) {
          const data = JSON.parse(event.data);
          const startLat = data.lat;
          const startLng = data.lng;

          const startPosition = new kakao.maps.LatLng(startLat, startLng);
          new kakao.maps.Marker({ position: startPosition, map: map });

          new kakao.maps.CustomOverlay({
            position: startPosition,
            content: '<div style="padding:5px; background:white; border:1px solid black; border-radius:3px;">출발</div>',
            yAnchor: 0
          }).setMap(map);

          const bounds = new kakao.maps.LatLngBounds();
          bounds.extend(startPosition);
          bounds.extend(endPosition);
          map.setBounds(bounds);

          fetch("https://apis-navi.kakaomobility.com/v1/directions?origin=" + startLng + "," + startLat + "&destination=" + endLng + "," + endLat, {
            method: "GET",
            headers: {
              Authorization: "KakaoAK ${KAKAO_MOBILITY_KEY}"
            }
          })
          .then(res => res.json())
          .then(data => {
            const linePath = [];
            data.routes[0].sections[0].roads.forEach(r => {
              r.vertexes.forEach((v, i) => {
                if (i % 2 === 0) linePath.push(new kakao.maps.LatLng(r.vertexes[i + 1], r.vertexes[i]));
              });
            });
            new kakao.maps.Polyline({
              path: linePath,
              strokeWeight: 5,
              strokeColor: "green",
              strokeOpacity: 0.7,
              strokeStyle: "solid"
            }).setMap(map);
          });
        });
      </script>
    </body>
    </html>
  `;

  return (
    <View style={styles.container}>
      <WebView
        originWhitelist={["*"]}
        source={{ html: htmlContent }}
        javaScriptEnabled={true}
        domStorageEnabled={true}
        injectedJavaScript={`(function() {
          window.console.log = function(message) {
            window.ReactNativeWebView.postMessage(message);
          }
        })();`}
        onMessage={(event) => console.log("WebView message:", event.nativeEvent.data)}
        style={styles.webview}
      />
    </View>
  );
});
export default KakaoMap;

const styles = StyleSheet.create({
  container: { width: "100%", height: 400 },
  webview: { flex: 1 },
});
