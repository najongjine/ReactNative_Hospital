// app/screens/KakaoMapScreen.tsx
import { ThemedText } from "@/components/ThemedText";
import { ThemedView } from "@/components/ThemedView";
import React from "react";
import { ScrollView, StyleSheet } from "react-native";

export default function KakaoMapScreen() {
  return (
    <ScrollView style={styles.container}>
      <ThemedView>
        <ThemedText type="title">kakao map!</ThemedText>
      </ThemedView>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  webview: {
    flex: 1,
  },
});
